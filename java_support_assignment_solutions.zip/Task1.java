import java.util.*;
public class Task1 {
    public List<LoanAccount> getOverdueLoans(List<LoanAccount> accounts) {
        List<LoanAccount> result = new ArrayList<>(); // FIX

        for (LoanAccount account : accounts) {
            if (account.getDueDate() != null && account.getDueDate().before(new Date())) { // FIX
                if (account.getOutstandingBalance() > 0) {
                    result.add(account);
                }
            }
        }
        return result;
    }
}