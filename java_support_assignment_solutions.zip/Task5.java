import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.*;

public class Task5 {

    private static final Logger logger = LoggerFactory.getLogger(Task5.class);

    public ValidationResult validate(Document doc) {
        try {
            if (doc == null) {
                throw new IllegalArgumentException("Document is null"); // FIX
            }

            String content = doc.extractContent();

            if (content.isEmpty()) {
                throw new IllegalArgumentException("Empty content"); // FIX
            }

            return runValidationRules(content);

        } catch (IllegalArgumentException e) {
            logger.warn("Validation failed: {}", e.getMessage()); // FIX
            return new ValidationResult(false);
        } catch (Exception e) {
            logger.error("Unexpected error", e); // FIX
            return new ValidationResult(false);
        }
    }

    public void validateBatch(List<Document> docs) {
        for (Document doc : docs) {
            try {
                ValidationResult r = validate(doc);

                if (r != null && r.isValid()) { // FIX
                    saveResult(r);
                }

            } catch (Exception e) {
                logger.error("Batch error", e); // FIX
            }
        }
    }

    private ValidationResult runValidationRules(String c) { return new ValidationResult(true); }
    private void saveResult(ValidationResult r) {}
}