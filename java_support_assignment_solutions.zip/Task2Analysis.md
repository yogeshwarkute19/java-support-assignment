# Task 2 Analysis

1. Cause:
ConcurrentModificationException occurs when modifying a collection during iteration.

2. Problem Code:
for (Transaction t : list) {
    list.remove(t);
}

3. Fix:
Iterator<Transaction> it = list.iterator();
while (it.hasNext()) {
    Transaction t = it.next();
    it.remove();
}
